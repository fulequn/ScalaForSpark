package com.bjsxt.scala

object Lesson_String {
  def main(args: Array[String]): Unit = {
    val s = "jsxbt"
    val s1 = "BJSXT"

    println(s.indexOf(98))
//    println(s.equals(s1))
//    println(s.equalsIgnoreCase(s1))
  }
}
